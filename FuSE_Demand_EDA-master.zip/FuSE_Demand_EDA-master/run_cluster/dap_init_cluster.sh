#!/bin/bash

#!/bin/bash

# This module provides DNS integration for Dataproc hosts
# between Kohl's DNS and Google DNS. It allows Dataproc nodes
# to resolve private Kohl's DNS records.
#
# All DNS requests will be sent to dnsmasq running on localhost,
# and forwarding requests to appropriate servers.

set -xe

cat >>/etc/apt/apt.conf <<EOF
Acquire::http::Proxy "http://10.4.7.10:3128";
EOF

set +e
RETRY_TIMEOUT=10
for i in $(seq 10); do
    if (apt-get -y update || true) && apt-get -y install dnsmasq ; then
        break
    fi
    echo "Sleeping $RETRY_TIMEOUT secs..."
    sleep $RETRY_TIMEOUT
done
set -e

cat > /etc/dnsmasq.conf <<EOF
# Never forward plain names (without a dot or domain part)
domain-needed

# Set the cachesize here.
cache-size=0

# Include another lot of configuration options.
conf-dir=/etc/dnsmasq.d

# DNS Server configuration
rev-server=10.206.0.0/16,169.254.169.254
server=/internal/169.254.169.254
server=10.1.42.219
server=10.1.42.218
server=10.1.28.247
server=10.7.28.247
server=10.220.0.247
EOF

GCP_PROJECT=$(/usr/share/google/get_metadata_value ../project/project-id)

cat >>/etc/dhcp/dhclient.conf <<EOF
supersede domain-name-servers 127.0.0.1;
supersede domain-search "kohls.com", "tst.kohls.com", "dc.kohls.com", "corp.kohls.com", "c.${GCP_PROJECT}.internal", "google.internal";
EOF

#Dirty hack for dnsmasq issue https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=860274
sed -i -e 's/^\([\t[:space:]]\+DNSMASQ_OPTS="$DNSMASQ_OPTS \).*/\1`mawk -- '"'"'{ printf " --trust-anchor=.,%d,%d,%d,%s", $5, $6, $7, $8 }'"'"' $ROOT_DS`"/g' /etc/init.d/dnsmasq

systemctl restart dnsmasq

systemctl daemon-reload

/usr/sbin/service networking reload

export http_proxy="http://10.4.7.10:3128"
export https_proxy="http://10.4.7.10:3128"

easy_install pip
requirements_file=requirements.txt
cat >> ${requirements_file} << EOF
xmltodict==0.12.0
google-cloud-storage==1.23.0
iso8601==0.1.12
uuid==1.30
pandas==0.24.2
ortools==7.3.7083
python-dateutil==2.8.0
joblib==0.14.0
google-cloud-bigquery==1.22.0
pandas-gbq==0.13.1
pyarrow==0.16.0
fastparquet==0.3.3
EOF
pip install -r ${requirements_file}
