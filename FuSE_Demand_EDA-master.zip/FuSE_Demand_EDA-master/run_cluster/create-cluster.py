import logging
import time

import googleapiclient.discovery

def create_cluster(dataproc, project, zone, region, cluster_name, bucket_name, subnetwork_uri):
    print('Creating cluster...')
    zone_uri = \
        'https://www.googleapis.com/compute/v1/projects/{}/zones/{}'.format(
            project, zone)
    cluster_data = {
        'projectId': project,
        'clusterName': cluster_name,
        'labels': {
            'app-name': 'fuse',
            'billing-dept-id': '90514',
            'eng-owner': 'gupta',
            'lob': 'merch'
        },
        'config': {
            'configBucket': bucket_name,
            'gceClusterConfig': {
                'zoneUri': zone_uri,
                'subnetwork_uri': subnetwork_uri,
                'tags': [ 'merch-in-lle-ssh' ],
                'internal_ip_only': "true"
            },
            'masterConfig': {
                'numInstances': 1,
                'machineTypeUri': 'n1-standard-96'
            },
            'softwareConfig': {
                # "image_version": "1.4.22-debian9",
                "properties": {
                    "dataproc:dataproc.allow.zero.workers": "true"
                },
                "optionalComponents": ['JUPYTER', 'ANACONDA']
            },
            'endpointConfig': {
                'enableHttpPortAccess': True
            },
            'initializationActions': {
                "executableFile": 'gs://kohls-merch-in-lle-dev-dataproc-bucket/dap_init_cluster.sh'
            }
        }
    }
    result = dataproc.projects().regions().clusters().create(
        projectId=project,
        region=region,
        body=cluster_data).execute()
    return result

def get_client():
    """Builds an http client authenticated with the service account credentials."""
    dataproc = googleapiclient.discovery.build('dataproc', 'v1')
    return dataproc

def wait_for_cluster_creation(dataproc, project_id, region, cluster_name):
    print('Waiting for cluster creation...')

    while True:
        time.sleep(10)
        result = dataproc.projects().regions().clusters().list(
            projectId=project_id,
            region=region).execute()
        cluster_list = result['clusters']
        cluster = [c
                   for c in cluster_list
                   if c['clusterName'] == cluster_name][0]
        if cluster['status']['state'] == 'ERROR':
            raise Exception(result['status']['details'])
        if cluster['status']['state'] == 'RUNNING':
            print("Cluster created.")
            break

dataproc = get_client()
fuse_project_id = 'kohls-merch-in-lle'
zone = 'us-central1-a'
region = 'us-central1'
cluster_name = 'ali-cluster'
fuse_bucket_name = 'kohls-merch-in-lle-dev-dataproc-bucket'
subnetwork_uri = 'projects/kohls-merch-xpn-lle/regions/us-central1/subnetworks/merch-in-lle-central1-prv01'

pyspark_file = 'example-pyspark.py'
fuse_dataset = 'INVENTORY_STG01'

create_cluster(dataproc, fuse_project_id, zone, region, cluster_name, fuse_bucket_name, subnetwork_uri)
wait_for_cluster_creation(dataproc, fuse_project_id, region, cluster_name)
