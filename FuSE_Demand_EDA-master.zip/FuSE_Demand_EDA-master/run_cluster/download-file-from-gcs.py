from google.cloud import storage

storage_client = storage.Client()
bucket_name = 'kohls-merch-in-lle-dev-dataproc-bucket'
blobs = storage_client.list_blobs(bucket_name, prefix='csv')

destination = './{}'

for blob in blobs:
    if blob.name.endswith('.csv'):
        local_file_name = blob.name[blob.name.rindex('/') + 1:]
        print(local_file_name)
        print('Downloading {} to {}'.format(blob.name, destination.format(local_file_name)))
        blob.download_to_filename(destination.format(local_file_name))
